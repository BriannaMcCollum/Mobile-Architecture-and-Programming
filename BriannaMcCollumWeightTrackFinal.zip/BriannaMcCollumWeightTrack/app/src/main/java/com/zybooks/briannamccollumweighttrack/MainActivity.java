package com.zybooks.briannamccollumweighttrack;

//static variables from android needed for sending the text message
import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.SEND_SMS;
import static android.Manifest.permission.READ_SMS;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    //Declare the widgets and databases
    GridLayout dataTable;
    TextView goalDisplay;
    EditText goalEdit;
    EditText dateEdit;
    EditText weightEdit;
    private AccountDatabase AccountDB;
    private WeightDatabase WeightDB;
    long accountID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //singleton pattern for databases
        AccountDB = AccountDatabase.getInstance(getApplicationContext());
        WeightDB = WeightDatabase.getInstance(getApplicationContext());

        //instantiate widgets by id
        dataTable = (GridLayout) findViewById(R.id.dataTable);
        goalDisplay = (TextView) findViewById(R.id.goalDisplay);
        goalEdit = (EditText) findViewById(R.id.goalEdit);
        dateEdit = (EditText) findViewById(R.id.dateEdit);
        weightEdit = (EditText) findViewById(R.id.weightEdit);

        //Get the Bundle from the Intent that started this Activity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            //Get the data out of the Bundle using the key
            accountID = extras.getLong("_id");
        } else {
            //no account defaults to an id of -1
            accountID = -1;
        }

        //update to fill information on the page based on the active account
        updatePage(accountID);
    }

    //fills in account information for the page
    private void updatePage(long accountID) {
        //sets the weight goal at the top of the screen
        float goal = AccountDB.getGoal(accountID);
        String goalText = "Weight Goal: " + goal + "lbs";
        goalDisplay.setText(goalText);

        //set the weight entries in the grid layout
        updateGrid(accountID);
    }

    //check to see if the user should be congratulated for a met weight goal.
    private void checkCongrats(long accountID) {
        //retrieve the current permission status from the active account
        int currentPerm = AccountDB.getPerms(accountID);

        //if the current permission status is 0 (default), do nothing
        if (currentPerm == 0) {
            return;
        } else {
            //get all of the entries from the database
            List<String> weightList = WeightDB.getAllWeights(accountID);
            int numEntries = weightList.size();

            //check if the user has met their weight goal
            //Loop through the weightList's entries, iterating by 2 each time
            for (int i = 0; i < numEntries; i = i + 2) {
                float tempWeight = Float.parseFloat(weightList.get(i + 1));
                //sees if the weight goal is equal to or greater than the current weight
                if (tempWeight <= AccountDB.getGoal(accountID)) {
                    //send the text message to congratulate the user
                    sendMessage();
                }
            }
        }
    }

    //updates the gridLayout to display all of the data entries
    private void updateGrid(long accountID) {
        // Get the amount of weight entries for the given account
        //do so by fetching all the data for the account then dividing the list's length by 2
        //since there are two values per entry (date and weight)
        List<String> weightList = WeightDB.getAllWeights(accountID);
        int numEntries = weightList.size();

        // Get application context.
        Context context = getApplicationContext();

        //remove the current entries from the gridLayout
        dataTable.removeAllViews();

        //Loop through the weightList's entries, iterating by 2 each time
        for (int i = 0; i < numEntries; i = i + 2) {
            //Create a text view component to hold the date.
            TextView dateText = new TextView(context);
            dateText.setTextAppearance(this, R.style.subTitle);
            dateText.setText(weightList.get(i));

            //Make another text view component to hold the weight.
            TextView weightText = new TextView(context);
            weightText.setTextAppearance(this, R.style.subTitle);
            weightText.setText(weightList.get(i + 1));

            //Insert date label at empty position that matches
            dataTable.addView(dateText);
            //Then Insert weight label at next empty position
            dataTable.addView(weightText);
        }

    }

    //adds a new weight into today's spot
    public void quickAdd(View view) {
        //check if the dateEdit or weightEdit is empty
        //if it is, error toast and stop the function
        if (TextUtils.isEmpty(dateEdit.getText().toString()) ||
                TextUtils.isEmpty(weightEdit.getText().toString())) {
            Toast.makeText(MainActivity.this, "Enter date and weight.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        //grab date and weight from the correct text edits
        String date = dateEdit.getText().toString();
        float weight = Float.parseFloat(weightEdit.getText().toString());

        //then insert the values into the weight database
        WeightDB.addEntry(accountID, date, weight);

        //for testing
        //WeightDB.addEntry(accountID, "12/12/2022", 180);

        //finally update the grid to display the added entry
        updateGrid(accountID);

        //if there's a weight entry that's less than the goal, send a congrats
        checkCongrats(accountID);
    }

    //Sets the user's weight goal
    public void setWeightGoal(View view) {
        //check if the goalEdit is empty
        //if it is, error toast and stop the function
        if (TextUtils.isEmpty(goalEdit.getText().toString())) {
            Toast.makeText(MainActivity.this, "Enter new Weight Goal.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        //the goalEdit text should be a float since the editText is set to number pad
        float goal = Float.parseFloat(goalEdit.getText().toString());

        //updates the goal in the database
        AccountDB.updateGoal(accountID, goal);
        //refresh the page to show new information
        updatePage(accountID);

        //if there's a weight entry that's less than the goal, send a congrats
        checkCongrats(accountID);
    }

    //swap's the user's account's value for permission to access the phone's text messaging app
    public void textPermission(View view) {
        //retrieve the current permission status from the active account
        int currentPerm = AccountDB.getPerms(accountID);

        //if the current permission status is 0 (default), permission hasn't been granted
        if (currentPerm == 0) {

            //ask the user for permission
            requestPermissions(new String[]{READ_SMS, READ_PHONE_NUMBERS, SEND_SMS}, 100);

            // Get application context.
            Context context = getApplicationContext();

            //checks if the user gave permission or not to change the account setting
            if (ContextCompat.checkSelfPermission(context,READ_SMS) == PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context,READ_PHONE_NUMBERS) == PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context,SEND_SMS) == PERMISSION_GRANTED) {
                //set the account permission to on and let user know
                AccountDB.updatePerms(accountID, 1);
                Toast.makeText(getApplicationContext(), "SMS notifications turned on!",
                        Toast.LENGTH_LONG).show();
            }

        } else {
            //set the account permission to off and let user know
            AccountDB.updatePerms(accountID, 0);
            Toast.makeText(getApplicationContext(), "SMS notifications turned off!",
                    Toast.LENGTH_LONG).show();
        }
    }

    public void sendMessage() {
        //make a text manager object, then send the text with the device's phone number
        SmsManager smsManager = SmsManager.getDefault();
        TelephonyManager phoneManager = (TelephonyManager)
                this.getSystemService(Context.TELEPHONY_SERVICE);
        //it's suppressed since you can only get to sendMessage with permission
        @SuppressLint("MissingPermission") String phoneNumber = phoneManager.getLine1Number();

        smsManager.sendTextMessage(phoneNumber, null,
                "Congratulations! You hit your weight goal!!", null, null);
        //put a toast as well just so the user sees
        Toast.makeText(getApplicationContext(), "Congratulations!",
                Toast.LENGTH_LONG).show();
    }

    //removes a weight entry from the weight database with matching data and weight
    public void deleteWeight(View view) {
        //check if the dateEdit or weightEdit is empty
        //if it is, error toast and stop the function
        if (TextUtils.isEmpty(dateEdit.getText().toString()) ||
                TextUtils.isEmpty(weightEdit.getText().toString())) {
            Toast.makeText(MainActivity.this, "Enter date and weight to remove",
                    Toast.LENGTH_LONG).show();
            return;
        }

        //grab date and weight from the correct text edits
        String date = dateEdit.getText().toString();
        float weight = Float.parseFloat(weightEdit.getText().toString());

        //then edit the desired values in the weight database
        //changes the weight paired with a specific date
        WeightDB.deleteSearch(accountID, date, weight);

        //finally update the grid to display the removed entry
        updateGrid(accountID);
    }

    //edits a previous weight entry in the weight database
    //changes the weight by looking for a specific date inside the given account's entries
    public void editWeight(View view) {
        //check if the dateEdit or weightEdit is empty
        //if it is, error toast and stop the function
        if (TextUtils.isEmpty(dateEdit.getText().toString()) ||
                TextUtils.isEmpty(weightEdit.getText().toString())) {
            Toast.makeText(MainActivity.this, "Enter date to find and weight to change.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        //grab date and weight from the correct text edits
        String date = dateEdit.getText().toString();
        float weight = Float.parseFloat(weightEdit.getText().toString());

        //then edit the desired values in the weight database
        //changes the weight paired with a specific date
        WeightDB.editWeightEntry(accountID, date, weight);

        //finally update the grid to display the edited entry
        updateGrid(accountID);

        //if there's a weight entry that's less than the goal, send a congrats
        checkCongrats(accountID);
    }
}