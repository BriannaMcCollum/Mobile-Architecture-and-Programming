package com.zybooks.briannamccollumweighttrack;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity  {

    //Declare the widgets and databases
    EditText username;
    EditText password;
    private AccountDatabase AccountDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //singleton pattern for databases
        AccountDB = AccountDatabase.getInstance(getApplicationContext());

        //instantiate widgets by id
        username = (EditText)findViewById(R.id.usernameEdit);
        password = (EditText)findViewById(R.id.passwordEdit);
    }

    public void startMainActivity(Intent intent){
        startActivity(intent);
    }

    //checks if the username and password equal an account in the system
    //if it does, send an intent to the main activity
    public void Login(View view) {
        String user = username.getText().toString();
        String pass = password.getText().toString();

        //check if either username or password is empty
        //if they are, error toast and stop the function
        if (TextUtils.isEmpty(username.getText().toString()) ||
                TextUtils.isEmpty(password.getText().toString())) {
            Toast.makeText(LoginActivity.this, "Enter Username and Password.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        // ---
        //ACCOUNT FOR TESTING (account should exist in the database)
        //username: user
        //password: pass123
        // ---

        //check if username and password is an account in the database
        //if id is a negative, then the account doesn't exist
        long id = AccountDB.getAccount(user, pass);
        if (id > 0) {
            //send the id to the main activity through an intent
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.putExtra("_id", id);
            startMainActivity(intent);
        }
        //account doesn't exist
        else {
            Toast.makeText(LoginActivity.this, "This account doesn't exist!",
                    Toast.LENGTH_LONG).show();
        }
    }

    //creates a new account in the database using the given username and password
    public void newAccount(View view) {
        //grab the username and password from the edit text objects and check them in getAccount
        String user = username.getText().toString();
        String pass = password.getText().toString();

        //check if either username or password is empty
        //if they are, error toast and stop the function
        if (TextUtils.isEmpty(username.getText().toString()) ||
                TextUtils.isEmpty(password.getText().toString())) {
            Toast.makeText(LoginActivity.this, "Enter Username and Password.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        //if id is a negative, then the account doesn't exist
        long id = AccountDB.getAccount(user, pass);
        //if the username provided belongs to an account, you can't make a new account with it
        if (id > 0) {
            Toast.makeText(LoginActivity.this, "This username already exists!",
                    Toast.LENGTH_LONG).show();
        }
        //unique username, can continue
        else {
            //creates the new account in the account database and records the new id
            long newID = AccountDB.addAccount(user, pass);

            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.putExtra("_id", newID);
            startMainActivity(intent);
        }
    }
}
