package com.zybooks.briannamccollumweighttrack;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Objects;

public class AccountDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "account.db";
    private static final int VERSION = 1;

    //singleton pattern: there is only one account database
    private static AccountDatabase AccountDB;

    public static AccountDatabase getInstance(Context context) {
        if (AccountDB == null) {
            AccountDB = new AccountDatabase(context);
        }
        return AccountDB;
    }

    //basic constructor, private for singleton pattern
    private AccountDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //table that provides column names for the database
    private static final class AccountTable {
        private static final String TABLE = "accounts";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_GOAL = "goal";
        private static final String COL_SMSPERM = "SMSperm";
    }

    //creates the table with the specified columns
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + AccountTable.TABLE + " (" +
                AccountTable.COL_ID + " integer primary key autoincrement, " +
                AccountTable.COL_USERNAME + " text, " +
                AccountTable.COL_PASSWORD + " text, " +
                AccountTable.COL_GOAL + " text, " +
                AccountTable.COL_SMSPERM + " integer)");
    }

    //called when the database's version is changed, to re-create the database with new information
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + AccountTable.TABLE);
        onCreate(db);
    }

    //adds a new account to the database, called by newAccount()
    public long addAccount(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        //create the list of values to put in the new row
        ContentValues values = new ContentValues();
        values.put(AccountTable.COL_USERNAME, username);
        values.put(AccountTable.COL_PASSWORD, password);
        values.put(AccountTable.COL_GOAL, "200");
        values.put(AccountTable.COL_SMSPERM, 0);

        return db.insert(AccountTable.TABLE, null, values);
    }

    //looks for an account by username and password, returning ID if a matching account is found
    public long getAccount(String User, String Pass) {
        //this id will change if an Account is found, stays negative if nothing is found
        long result = -1;
        SQLiteDatabase db = getReadableDatabase();

        //start a query to look for our account based on usernames, which are unique
        String sql = "select * from " + AccountTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { User });
        if (cursor.moveToFirst()) {
            do {
                //get all the info out of the current account
                long id = cursor.getLong(0);
                String username = cursor.getString(1);
                String password = cursor.getString(2);
                float goal = cursor.getFloat(3);
                int smsPerm = cursor.getInt(4);

                //if the username and password of the given account is the same, then it's a match
                //change result to the id
                if(Objects.equals(username, User) && Objects.equals(password, Pass)) {
                    result = id;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        return result;
    }

    //gets the weight goal value from the database
    public float getGoal(long id){
        //this weight goal will change if an Account is found, stays negative if nothing is found
        float goal = -1;
        SQLiteDatabase db = this.getReadableDatabase();

        //start a query to look for our account based on id, which are unique
        String sql = "select * from " + AccountTable.TABLE + " where _id = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {String.valueOf(id)});
        if (cursor.moveToFirst()) {
            do {
                //get the info needed
                goal = cursor.getFloat(3);
            }while (cursor.moveToNext());
        }
        cursor.close();

        return goal;
    }

    //updates the weight goal for a specific account, which is by default set to 200
    //called by setWeightGoal
    public void updateGoal(long id, float goal) {
        SQLiteDatabase db = getWritableDatabase();

        //creates the value that will be changed
        ContentValues values = new ContentValues();
        values.put(AccountTable.COL_GOAL, goal);

        //updates the correct database by searching for _id, returning how many rows were changed
        int rowsUpdated = db.update(AccountTable.TABLE, values, "_id = ?",
                new String[] { Long.toString(id) });
    }

    //gets the current permission value from the database
    public int getPerms(long id){
        //this weight goal will change if an Account is found, stays negative if nothing is found
        int smsPerm = -1;
        SQLiteDatabase db = this.getReadableDatabase();

        //start a query to look for our account based on id, which are unique
        String sql = "select * from " + AccountTable.TABLE + " where _id = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {String.valueOf(id)});
        if (cursor.moveToFirst()) {
            do {
                //get the info needed
                smsPerm = cursor.getInt(4);
            }while (cursor.moveToNext());
        }
        cursor.close();

        return smsPerm;
    }

    //called by textPermission(), changes the value of smsPerm to either 0 or 1
    public void updatePerms(long id, int smsPerm) {
        SQLiteDatabase db = getWritableDatabase();

        //creates the value that will be changed
        ContentValues values = new ContentValues();
        values.put(AccountTable.COL_SMSPERM, smsPerm);

        //updates the correct database by searching for _id, returning how many rows were changed
        int rowsUpdated = db.update(AccountTable.TABLE, values, "_id = ?",
                new String[] { Long.toString(id) });
    }

}

