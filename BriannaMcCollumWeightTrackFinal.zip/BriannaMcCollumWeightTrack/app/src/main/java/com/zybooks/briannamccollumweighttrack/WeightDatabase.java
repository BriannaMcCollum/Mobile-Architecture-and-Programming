package com.zybooks.briannamccollumweighttrack;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class WeightDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight.db";
    private static final int VERSION = 2;

    //singleton pattern: there is only one weight database
    private static WeightDatabase WeightDB;

    public static WeightDatabase getInstance(Context context) {
        if (WeightDB == null) {
            WeightDB = new WeightDatabase(context);
        }
        return WeightDB;
    }

    //basic constructor, private for singleton pattern
    private WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //table that provides column names for the database
    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_DAILYW = "daily_weight";
    }

    //creates the table with the specified columns
    //the ID can be repeats here, since the id connects an entry with an account
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " integer, " +
                WeightTable.COL_DATE + " text, " +
                WeightTable.COL_DAILYW + " float)");
    }

    //called when the database's version is changed, to re-create the database with new information
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }

    //adds a new weight entry to the database, called by quickAdd()
    public void addEntry(long id, String date, float weight) {
        SQLiteDatabase db = getWritableDatabase();

        //create the list of values to put in the new row
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_ID, id);
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_DAILYW, weight);

        db.insert(WeightTable.TABLE, null, values);
    }

    //directly interacts with the database to edit an entry
    private void updateEntry(long id, String date, float weight) {
        SQLiteDatabase db = getWritableDatabase();

        //create the list of values to put in the new row
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_ID, id);
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_DAILYW, weight);

        db.update(WeightTable.TABLE, values, "date=?", new String[]{date});
    }

    //directly interacts with the database to remove an entry
    private void deleteEntry(long id, String date, float weight) {
        //grab the database to delete from
        SQLiteDatabase db = getWritableDatabase();

        //create the list of values to put in the new row
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_ID, id);
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_DAILYW, weight);

        db.delete(WeightTable.TABLE, "_id=? and date=?",
                new String[]{String.valueOf(id), date});
    }

    //change an entry in the database by searching for the date and changing the weight
    public void editWeightEntry(long id, String date, float weight){
        //variable to hold the dates we find in the database
        String date2;

        SQLiteDatabase db = this.getReadableDatabase();

        //start a query to look for our account based on id, which are unique
        String sql = "select * from " + WeightTable.TABLE + " where _id = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {String.valueOf(id)});
        if (cursor.moveToFirst()) {
            do {
                //get the info needed
                date2 = cursor.getString(1);
                //If we've found the right date, change the weight to the weight value
                if (Objects.equals(date, date2)){
                    //actual update private method
                    updateEntry(id, date, weight);
                }
            }while (cursor.moveToNext());
        }
        cursor.close();
    }

    //find a desired entry for deletion, and when found invoke deleteEntry() to remove it
    public void deleteSearch(long id, String date, float weight){
        //variable to hold the dates and weights we find in the database
        String date2;
        float weight2;

        SQLiteDatabase db = this.getReadableDatabase();

        //start a query to look for our account based on id, which are unique
        String sql = "select * from " + WeightTable.TABLE + " where _id = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {String.valueOf(id)});
        if (cursor.moveToFirst()) {
            do {
                //get the info needed
                date2 = cursor.getString(1);
                weight2 = cursor.getFloat(2);
                if(Objects.equals(date, date2) && weight == weight2){
                    //actual deletion private method
                    deleteEntry(id, date, weight);
                }
            }while (cursor.moveToNext());
        }
        cursor.close();
    }

    //fetches all the data entries for an account and places them in one list
    public List<String> getAllWeights(long id){
        //initialize our List
        List<String> weightList =  new ArrayList<String>();
        String date;
        float weight;

        SQLiteDatabase db = this.getReadableDatabase();

        //start a query to look for our account based on id, which are unique
        String sql = "select * from " + WeightTable.TABLE + " where _id = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {String.valueOf(id)});
        if (cursor.moveToFirst()) {
            do {
                //get the info needed
                date = cursor.getString(1);
                weight = cursor.getFloat(2);
                weightList.add(date);
                weightList.add(String.valueOf(weight));
            }while (cursor.moveToNext());
        }
        cursor.close();

        return weightList;
    }

}
